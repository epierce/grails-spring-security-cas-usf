grails.project.class.dir = 'target/classes'
grails.project.test.class.dir = 'target/test-classes'
grails.project.test.reports.dir	= 'target/test-reports'
grails.project.docs.output.dir = 'docs' // for backwards-compatibility, the docs are checked into gh-pages branch

//Add JIRA Studio as a plugin repository
grails.plugin.repos.discovery.usfRepository = "https://bullpen.jira.com/svn/GRAILSPLUGIN"
grails.plugin.repos.distribution.usfRepository = "https://bullpen.jira.com/svn/GRAILSPLUGIN"

grails.project.dependency.resolution = {
	inherits('global') {
		excludes 'commons-codec' // Grails ships with 1.3, need 1.4
	}

	log 'warn'

	repositories {        
		grailsPlugins()
		grailsHome()
		grailsCentral()

		ebr() // SpringSource  http://www.springsource.com/repository
		
		mavenLocal()
		mavenCentral()
		mavenRepo "http://snapshots.repository.codehaus.org"
		mavenRepo "http://repository.codehaus.org"
		mavenRepo "http://download.java.net/maven/2/"
		mavenRepo "http://repository.jboss.com/maven2/"
	}

	dependencies {
		compile('org.springframework.security:org.springframework.security.cas:3.0.4.RELEASE') {
			transitive = false
		}
		compile('org.jasig.cas:com.springsource.org.jasig.cas.client:3.1.8') {
			transitive = false
		}
		compile('org.opensaml:opensaml:1.1') {
			transitive = false
		}
		compile('xml-security:xmlsec:1.3.0') {
			transitive = false
		}
	}
}
