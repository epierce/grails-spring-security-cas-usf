package edu.usf.cims

import grails.plugins.springsecurity.SpringSecurityService
import org.springframework.web.context.request.RequestContextHolder

class UsfCasService extends SpringSecurityService {

    static transactional = false
	static scope = "singleton"
	
	//def request = RequestContextHolder.requestAttributes.request
	def webRequest = RequestContextHolder.currentRequestAttributes()

	def getUsername(){
		super.authentication.name
	}
    def getAttributes(){
		webRequest.userPrincipal.assertion.principal.attributes
	}
	
	def getEppa() {
		webRequest.userPrincipal.assertion.principal.attributes.eduPersonPrimaryAffiliation
    }
	
	def getAffiliation(){
		webRequest.userPrincipal.assertion.principal.attributes.eduPersonAffiliation
	}
}
